import { create } from "zustand";

interface Todo{
    todos:string[],
    addTodo:(todo:string)=>void,
    removeTodo:(todo:string)=>void
}

const useStore = create<Todo>((set)=>({
    todos:[],
    addTodo:(todo)=>set((state)=>({todos:[todo,...state.todos]})),
    removeTodo:(todoName)=>set((state)=>({todos:state.todos.filter((todo)=>todo!=todoName)}))
}))

export default useStore