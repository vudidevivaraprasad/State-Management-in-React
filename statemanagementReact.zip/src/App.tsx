import { useReducer } from "react"
import Counter from "./components/counter"
import NavBar from "./components/NavBar"
import TodoList from "./components/TodoList"
import todoReducer from "./components/Reducer/todoReducer"
import TodoContext from "./components/context/todoContext"

function App() {
  const [Todo,dispatch] = useReducer(todoReducer,[])

  return(
    // <Counter />
    <TodoContext.Provider value={{Todo,dispatch}}>
      <NavBar />
      <TodoList />
    </TodoContext.Provider>
  )
}

export default App
