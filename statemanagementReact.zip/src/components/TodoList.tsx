import { useContext, useReducer } from "react"
import todoReducer from "./Reducer/todoReducer"
import TodoContext from "./context/todoContext"
import useStore from "../store"

const TodoList = () => {
    // const {Todo,dispatch} = useContext(TodoContext)
    const {todos,addTodo,removeTodo} = useStore()
    // const [Todo,setTodo] = useState<string[]>([])

    // function addtodo(){
    //     setTodo([...Todo,String(new Date())])
    // }

    // function RemoveTodo(todo1:string){
    //     setTodo(Todo.filter(todo => todo !=todo1))
    // }

    return (
        <>
            <button onClick={()=>addTodo(String(Date.now()))}>AddTodo</button>
            <ul>
                {todos.map((todo,index) => 
                    <li key={index}>Todo {todo} <button onClick={()=>removeTodo(todo)}>DELETE</button></li>)}
            </ul>
        </>
    )
}

export default TodoList