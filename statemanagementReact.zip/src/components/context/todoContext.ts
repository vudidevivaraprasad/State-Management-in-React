import { Dispatch } from "react";
import { todoAction } from "../Reducer/todoReducer";
import React from "react";

interface TodoContextType {
    Todo:string[],
    dispatch:Dispatch<todoAction>
}

const TodoContext = React.createContext<TodoContextType>({} as TodoContextType)

export default TodoContext