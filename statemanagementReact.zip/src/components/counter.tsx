import { useReducer } from "react"
import countReducer from "./Reducer/countReducer"

const counter = () => {
    // const [count,setCount] = useState(0)
    const [count,dispatch] = useReducer(countReducer,0)
    return (
        <>
            <p>count{count}</p>
            <button onClick={()=>dispatch({type:'INCREASE'})}>Increase</button>
            <button onClick={()=>dispatch({type:'DECREASE'})}>Decrese</button>
        </>
    )
}

export default counter