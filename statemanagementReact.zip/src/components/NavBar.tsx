import { useContext } from "react"
import TodoContext from "./context/todoContext"
import useStore from "../store"

const NavBar = () => {
    // const {Todo} = useContext(TodoContext)
    const todos = useStore((state)=> state.todos)
    return(
        <p>{todos.length}</p>
    )
}

export default NavBar