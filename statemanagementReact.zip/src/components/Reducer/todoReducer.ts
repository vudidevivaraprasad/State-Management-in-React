interface Addaction{
    type:'ADD' 
}

interface Deleteaction {
    type:'REMOVE',
    value: string
}

export type todoAction = Addaction | Deleteaction

const todoReducer = (Todos:string[],action:todoAction):string[]  => {
    if(action.type=='ADD')  return [...Todos,String(Date.now())]
    if(action.type=='REMOVE') return Todos.filter(Todo => Todo !=action.value)
    return Todos
}

export default todoReducer