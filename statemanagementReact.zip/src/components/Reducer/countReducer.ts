interface Props {
    type:'INCREASE' | 'DECREASE'
}

const countReducer = (state:number,action:Props):number => {
    if(action.type=='INCREASE') return state+1
    if(action.type=='DECREASE') return state-1
    return state
}

export default countReducer